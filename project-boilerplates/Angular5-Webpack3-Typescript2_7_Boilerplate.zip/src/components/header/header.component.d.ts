export declare class HeaderComponent {
}
