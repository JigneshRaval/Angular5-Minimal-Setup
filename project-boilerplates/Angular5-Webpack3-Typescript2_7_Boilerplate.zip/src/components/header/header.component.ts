import { Component } from '@angular/core';

@Component({
    selector: 'header-component',
    templateUrl: 'src/components/header/header.component.html'
})
export class HeaderComponent {

}
