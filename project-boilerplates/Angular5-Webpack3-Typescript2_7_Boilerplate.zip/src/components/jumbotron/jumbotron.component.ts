import { Component } from '@angular/core';

@Component({
    selector: 'jumbotron-component',
    templateUrl: 'src/components/jumbotron/jumbotron.component.html'
})
export class JumbotronComponent {

}
