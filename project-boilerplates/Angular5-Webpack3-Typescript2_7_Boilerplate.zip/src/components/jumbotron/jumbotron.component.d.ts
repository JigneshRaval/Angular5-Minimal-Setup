export declare class JumbotronComponent {
}
