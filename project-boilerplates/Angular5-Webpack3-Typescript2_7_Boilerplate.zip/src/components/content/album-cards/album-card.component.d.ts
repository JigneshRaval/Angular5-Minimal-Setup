export declare class AlbumCardComponent {
    cardsList: any[];
    constructor();
}
