export declare class AppComponent {
}
