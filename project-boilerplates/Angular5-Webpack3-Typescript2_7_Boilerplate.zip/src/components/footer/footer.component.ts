import { Component } from '@angular/core';

@Component({
    selector: 'footer-component',
    templateUrl: 'src/components/footer/footer.component.html'
})
export class FooterComponent {

}
