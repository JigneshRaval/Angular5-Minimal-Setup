export declare class FooterComponent {
}
